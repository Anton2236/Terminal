# Terminal
Bluetooth Terminal

An app that connects to bluetooth devices such as arduino devices, and exchanges messages with them

Connects to bluetooth sockets instead of ip sockets